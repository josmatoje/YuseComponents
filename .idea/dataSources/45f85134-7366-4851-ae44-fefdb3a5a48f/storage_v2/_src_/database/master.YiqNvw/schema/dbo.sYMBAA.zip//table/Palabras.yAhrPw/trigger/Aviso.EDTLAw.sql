CREATE TRIGGER Aviso ON Palabras AFTER INSERT AS
	IF EXISTS (SELECT * FROM Inserted WHERE LEN(Palabra) > 10)
		PRINT 'Lo bueno si breve...'
go

