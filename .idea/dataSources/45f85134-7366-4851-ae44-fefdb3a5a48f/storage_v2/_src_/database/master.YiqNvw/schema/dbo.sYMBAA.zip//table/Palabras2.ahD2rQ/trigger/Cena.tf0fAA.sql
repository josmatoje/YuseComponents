-- Genera una fila adicional
CREATE TRIGGER Cena ON Palabras2 AFTER INSERT AS
BEGIN
	DECLARE @PalabraInsertada Varchar(20)
	SELECT @PalabraInsertada = Palabra FROM inserted
	PRINT 'Fila insertada en Palabras2'
	INSERT INTO Palabras2 (Palabra) VALUES ('Otro '+@PalabraInsertada )
END
go

