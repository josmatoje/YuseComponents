-- Lo mismo pero haciendo JOIN con la vista
CREATE TRIGGER AvisoLargo ON Palabras AFTER INSERT AS
	IF EXISTS (SELECT * FROM Inserted AS I 
						JOIN PalabrasLargas AS PL ON I.ID = PL.ID)
		PRINT '...dos veces bueno'
go

