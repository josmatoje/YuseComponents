-- Prueba de INSTEAD OF con vistas
create VIEW PalabrasLargas AS
	SELECT ID, Palabra FROM dbo.Palabras WHERE LEN(Palabra) > 10
go

