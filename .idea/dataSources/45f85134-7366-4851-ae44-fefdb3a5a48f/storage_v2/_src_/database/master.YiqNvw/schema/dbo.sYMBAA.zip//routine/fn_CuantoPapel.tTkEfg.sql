CREATE FUNCTION fn_CuantoPapel(@fechaI smalldatetime, @fechaF smalldatetime)

	RETURNS DECIMAL(10,2) AS
	BEGIN
		DECLARE @totalPapel DECIMAL(10,2) 

		IF @fechaF<@fechaI
			BEGIN
				SET @totalPapel=0
			END
		ELSE
			BEGIN
				SELECT @totalPapel=SUM((((Alto*Ancho)+(Alto*Largo)+(Largo*Ancho))*2*1.8)/1000)
				FROM TL_PaquetesNormales 
				WHERE FechaEntrega BETWEEN @FechaI AND @fechaF
			END
		RETURN @totalPapel
	END
go

