-- Solo se pueden insertar palabras los días impares
CREATE TRIGGER Chorrada ON Palabras2 AFTER INSERT,UPDATE AS
BEGIN
	IF DAY(GetDate()) % 2 = 0
		ROLLBACK
END -- TRIGGER
go

